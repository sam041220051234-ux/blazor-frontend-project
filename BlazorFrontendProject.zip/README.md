# Blazor Frontend Project

This is a minimal Blazor WebAssembly project prepared for Coursera submission.
Unzip and open the folder in Visual Studio or VS Code. Then build and run.

## How to use

1. Unzip the project.
2. Open the folder in Visual Studio 2022+ or VS Code with the C# extension.
3. Run `dotnet restore` and `dotnet run` or use the IDE run command.
4. Commit the files to a GitHub repository and paste the repo URL into Coursera.

## Files included
- Program.cs
- App.razor
- Pages (Index, Counter, FetchData)
- Shared (MainLayout, NavMenu)
- wwwroot/index.html and basic CSS
- BlazorFrontendProject.csproj
